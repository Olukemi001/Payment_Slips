# Load the necessary package
library(dplyr)

# Lists of 20 first names and 25 last names
first_names <- c("Ade", "Bola", "Caleb", "Dayo", "Effiong", "Fola", "Gbenga", "Helen", "Ife", 
                 "John", "Kemi", "Linda", "Mary", "Nosa", "Ope", "Pelumi", "Morgan", "Rose", "Steven", "Titi")
last_names <- c("Abodunrin", "Bamidele", "Kolawole", "Durodola", "Eniolorunda", "Fashola", "Gbolagade", "Olorunjube", "Roberts", 
                "Popoola", "Nicholas", "Sobowale", "Mayegun", "Wangai", "Hundeyin", "Temidayo", "Lasisi", "Iluyomade", 
                "Motunrayo", "Jakande", "Caleb", "Rasheed", "Wuraola", "Yomi", "Debare")

# Generate 450 unique names
set.seed(123) # For reproducibility
unique_names <- unique(c())
while (length(unique_names) < 450) {
  first_name <- sample(first_names, 1)
  last_name <- sample(last_names, 1)
  full_name <- paste(first_name, last_name)
  unique_names <- unique(c(unique_names, full_name))
}

# Step 1: Generate worker data dynamically using the unique names
workers <- list()
for (i in 1:length(unique_names)) {
  staff <- paste0("Staff_", i)
  name <- unique_names[i]
  salary <- sample(5000:50000, 1)
  gender <- sample(c("Male", "Female"), 1)
  workers[[i]] <- list(staff = staff, name = name, salary = salary, gender = gender)
}

# Display the first 5 workers as a sample
for (i in 1:5) {
  worker <- workers[[i]]
  print(worker)
}

# Loop to generate payment slips
for (worker in workers) {
  tryCatch({
    # Extract variables
    staff <- worker$staff
    name <- worker$name
    salary <- worker$salary
    gender <- worker$gender
    
    # Conditional Statements
    if (salary > 10000 && salary < 20000) {
      level <- "A1"
    } else if (salary > 7500 && salary < 30000 && gender == "Female") {
      level <- "A5-F"
    } else {
      level <- "NA"
    }
    
    # Generate Payment Slip
    cat("Payment Slip for", name, "\n")
    cat("Salary: $", salary, "\n")
    cat("Gender:", gender, "\n")
    cat("Employee Level:", level, "\n")
    cat("-------------\n")
  }, error = function(e) {
    cat("Error processing", worker$name, ":", e$message, "\n")
  })
}

